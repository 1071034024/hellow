
public class Button {

    private ButtonListener listener;//button监听器
    public int countclick = 0;//记录按钮被单击的次数
    public int countdoubleclick = 0;//记录按钮被双击的次数

    public void click()
    {
        System.out.println("*****按钮被单击*****");
        if(listener != null)
        {
            listener.doclick(new Event(this));
        }

    }

    public void doubleclick()
    {
        System.out.println("*****按钮被双击******");
        if(listener!=null)
        {
            listener.dodoubleclick(new Event(this));
        }

    }
    //注册监听器
    public void registerListener(ButtonListener listener)
    {
        this.listener = listener;
    }

}
