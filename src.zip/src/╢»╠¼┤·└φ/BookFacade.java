package 动态代理;

public interface BookFacade {
    public void addBook();
    public void deleteBook();
}
