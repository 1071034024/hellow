package 动态代理;

public class BookFacedeImpl implements BookFacade {
    @Override
    public void addBook() {
        System.out.println("增加方法....");
    }
    @Override
    public void deleteBook() {
        System.out.println("删除方法...");
    }
}
