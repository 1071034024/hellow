package 动态代理;

public class TestProxy {
    public static void main(String[] args){
        BookFacedeProxy proxy = new BookFacedeProxy();
        BookFacade bookProxy = (BookFacade) proxy.bind(new BookFacedeImpl());
        bookProxy.addBook();
        System.out.println("*******************");
        bookProxy.deleteBook();
    }
}
