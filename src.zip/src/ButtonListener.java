public interface ButtonListener {
    void  doclick(Event e);
    //触发双击事件
    void  dodoubleclick(Event e);
}
