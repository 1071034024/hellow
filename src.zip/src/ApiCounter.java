import com.alibaba.fastjson.JSON;
import org.apache.log4j.Logger;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class ApiCounter {

    private static final Logger logger = Logger.getLogger(ApiCounter.class);

    private AtomicLong totalQueryCount = new AtomicLong(0);
    private AtomicLong successQueryCount = new AtomicLong(0);
    private static Map<String, String> urlInfo = new HashMap<>();

    public void totalQueryIncrement() {
        totalQueryCount.incrementAndGet();
    }
    public long getTotalQueryCount() {
        return totalQueryCount.get();
    }
    public void successQueryIncrement() {
        successQueryCount.incrementAndGet();
    }
    public long getSuccessQueryCount() {
        return successQueryCount.get();
    }

    public void resultIncrement(String url){
        Date date = new Date();
        String queryAt = DateTimeHelper.formatDateYmdHms(date);

        try{
            boolean flag = urlInfo.containsKey(ConstantArguments.OPERATED_START_AT);
            if (flag == false){
                urlInfo.put(ConstantArguments.OPERATED_START_AT, queryAt);
            }
            urlInfo.put(ConstantArguments.QUERY_URL, url);
            urlInfo.put(ConstantArguments.OPERATED_NUMS, String.valueOf(ApiMetric.getTotalNum()));
            urlInfo.put(ConstantArguments.OPERATED_SUCCESS_NUMS, String.valueOf(ApiMetric.getSuccessNum()));
            urlInfo.put(ConstantArguments.OPERATED_FAILED_NUMS, String.valueOf(ApiMetric.getTotalNum() - ApiMetric.getSuccessNum()));
            urlInfo.put(ConstantArguments.LAST_OPERATED_AT, queryAt);

        }catch (Exception e){
            logger.error(e);
            urlInfo.put(ConstantArguments.LAST_OPERATED_AT, queryAt);
            urlInfo.put(ConstantArguments.ERROR_MSG, e.getMessage());
            urlInfo.put(ConstantArguments.ERROR_CODE, ConstantArguments.DEFAULT_ERRORCODE);
        }
    }

    public String getUrlInfo(){
        return JSON.toJSONString(urlInfo);
    }

    public void clear() {
        successQueryCount.set(0);
        totalQueryCount.set(0);
        urlInfo.clear();
    }

}
