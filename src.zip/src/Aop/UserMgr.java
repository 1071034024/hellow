package Aop;

//用户管理接口
public interface UserMgr {
    void addUser();
    void delUser();
}
