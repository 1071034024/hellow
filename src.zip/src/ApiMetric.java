import com.alibaba.fastjson.JSONObject;
import org.apache.log4j.Logger;

public final class ApiMetric {
    private static final Logger logger = Logger.getLogger(ApiMetric.class);

    private static ApiCounter totalResult = new ApiCounter();
    private static ApiCounter readUrlCount = new ApiCounter();

    public static void queryIncrement() {
        System.out.println(": " + readUrlCount.getTotalQueryCount());
        readUrlCount.totalQueryIncrement();
    }
    public static void queryIncrement(final boolean isSuccess) {
        if (isSuccess) {
            readUrlCount.successQueryIncrement();
        }
    }

    public static long getTotalNum(){
        return readUrlCount.getTotalQueryCount();
    }
    public static long getSuccessNum(){
        return readUrlCount.getSuccessQueryCount();
    }

    public static void urlInfo(String url){
        totalResult.resultIncrement(url);
    }

    public static JSONObject resultToJson() {
        JSONObject resultJson = new JSONObject();

        try {
            JSONObject urlInfoJson = new JSONObject();
            urlInfoJson.put(ConstantArguments.OPERATED_INFO, totalResult.getUrlInfo());
            resultJson.put(ConstantArguments.OPERATED_RECORD, urlInfoJson);
        }catch (Exception e) {
            logger.error(e);
            resultJson.put(ConstantArguments.ERROR_MSG, e.getMessage());
            resultJson.put(ConstantArguments.ERROR_CODE, ConstantArguments.DEFAULT_ERRORCODE);
        }
        return resultJson;
    }

    public static void clear(){
        readUrlCount.clear();
        totalResult.clear();
    }

}
