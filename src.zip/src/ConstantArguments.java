public class ConstantArguments {
    public static final String QUERY_URL = "query_url";
    public static final String OPERATED_NUMS = "operated_nums";
    public static final String OPERATED_SUCCESS_NUMS = "operated_success_nums";
    public static final String OPERATED_FAILED_NUMS = "operated_failed_nums";
    public static final String OPERATED_START_AT = "operated_start_at";
    public static final String LAST_OPERATED_AT = "last_operated_at";
    public static final String OPERATED_RECORD = "operated_record";
    public static final String OPERATED_INFO = "operated_info";
//    public static final String BUILD_VERTEX = "build_vertex";
//    public static final String BUILD_EDGE = "build_edge";
//    public static final String BUILD_VERTEX_COMMAND = "build_vertex_command";
//    public static final String BUILD_EDGE_COMMAND = "build_edge_command";
//    public static final String DELETE_VERTEX = "delete_vertex";
//    public static final String DELETE_EDGE = "delete_edge";
//    public static final String VERTEX_ID = "vertex_id";
//    public static final String DELETE_VERTEX_COMMAND = "delete_vertex_command";
//    public static final String DELETE_EDGE_COMMAND = "delete_edge_command";

    public static final String ERROR_MSG = "errorMessage";
    public static final String ERROR_CODE = "errorCode";
    public static final String DEFAULT_ERRORCODE = "GES.8000";
}
