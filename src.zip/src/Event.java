public class Event {
    private Button source;
    public Event(Button source)
    {
        this.source = source;
    }

    public Button getSource()
    {
        return source;
    }

    public void setSource(Button source)
    {
        this.source = source;
    }
}
