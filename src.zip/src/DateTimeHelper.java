import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTimeHelper {
    public static final String FORMAT_YMD_HMS = "yyyy-MM-dd HH:mm:ss";
    public static String formatDate(Date date, String format)
    {
        if (date == null)
        {
            return "";
        }
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        return formatter.format(date);
    }
    public static String formatDateYmdHms(Date date)
    {
        return formatDate(date, FORMAT_YMD_HMS);
    }
}
