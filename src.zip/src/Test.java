public class Test {
    public static void main(String[] args) {
        Button btn = new Button();
        //注册监听器
        btn.registerListener(new ButtonListener() {
            //触发单击事件
            @Override
            public void doclick(Event e) {
                Button btn = e.getSource() ;
                btn.countclick ++ ;
                System.out.println("弹出对话框按钮被单击了" + btn.countclick+"次") ;//模拟弹出对话框

            }
            //触发双击事件
            @Override
            public void dodoubleclick(Event e) {
                Button btn = e.getSource() ;
                btn.countdoubleclick ++ ;
                System.out.println("弹出对话框按钮被双击了" + btn.countdoubleclick+"次") ;//模拟弹出对话框
            }

        });
        //模拟按钮被单击
        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                for(int i=0;i<10;i++)
                {
                    btn.click();
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

            }

        });
        //模拟按钮被双击击
        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                for(int i=0;i<10;i++)
                {
                    btn.doubleclick();
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

            }

        });

        t1.start();
//        t2.start();
    }
}
