import com.alibaba.fastjson.JSONObject;

public class TestApi {

    public static void main(String[] args){
        String url = "http:// xxxxx ";
        for (int i = 0; i < 10; i++){
            ApiMetric.queryIncrement();
            if (i == 5 || i == 6 || i == 7 || i == 8){
                ApiMetric.queryIncrement(true);
            }
            try {
                Thread.sleep(1000);
            } catch (Exception e) {
                System.out.println(e);
            }
            ApiMetric.urlInfo(url);
        }
        JSONObject info = ApiMetric.resultToJson();
        System.out.println(": " + info);

        ApiMetric.clear();
        JSONObject info1 = ApiMetric.resultToJson();
        System.out.println(": " + info1);
    }
}
